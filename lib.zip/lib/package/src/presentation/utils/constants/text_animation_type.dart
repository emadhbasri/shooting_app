enum TextAnimationType {
  none,
  fade,
  typer,
  typeWriter,
  scale,
  colorize,
  wavy,
  flicker
}
