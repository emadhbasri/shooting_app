enum ItemType { image, text, video, gif }
