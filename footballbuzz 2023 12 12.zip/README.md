

de	German
it	Italian
es	Spanish
fr	French
pt	Portuguese
sa	Arabic


zh	Chinese
ja	Japanese
ru	Russian
pl	Polish
el	Greek
sr  Serbian
hi  India
nl  Netherlands

tr  Turkish
da  Danish
se  Sweden
no  Norwegian
bg	Bulgarian
cs  Czech


flutter gen-l10n