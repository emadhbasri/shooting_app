import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shooting_app/classes/states/match_state.dart';
import 'package:shooting_app/classes/states/theme_state.dart';
import 'package:shooting_app/main.dart';
import 'package:shooting_app/ui_items/my_toast.dart';
import 'package:shooting_app/ui_items/shots/index.dart';

class Header extends StatelessWidget {
  const Header({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer2<MatchState, ThemeState>(
      builder: (context, state, theme, child) {
        print('state.selectedHeader ${state.selectedHeader}');
        return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Builder(
                builder: (context) {
                  late Color backColor;
                  late Color color = Colors.black;
                  bool selected = state.selectedHeader == 'Live';
                  if (selected) {
                    if (theme.isDarkMode) {
                      backColor = mainGreen;
                    } else {
                      backColor = mainColor.withOpacity(.9);
                      color = Colors.white;
                    }
                  } else {
                    if (theme.isDarkMode) {
                      backColor = Colors.white;
                    } else {
                      backColor = colorGray3;
                    }
                  }
                  return InkWell(
                    borderRadius: BorderRadius.circular(5),
                    onTap: () {
                      state.selectedHeader = 'Live';
                      state.selectedDateTime = state.dateTimes[2];
                      state.notify();
                      state.getMatchsV2();
                    },
                    child: Ink(
                      decoration: BoxDecoration(
                        color: backColor,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      padding: EdgeInsets.symmetric(
                          horizontal: doubleWidth(2),
                          vertical: doubleHeight(.5)),
                      child: Text('LIVE',
                          style: TextStyle(
                            color: color,
                          )),
                    ),
                  );
                },
              ),
              ...state.headDates.map((e) {
                int index = state.headDates.indexOf(e);
                bool selected = state.selectedHeader == e;
                return TextButton(
                    style: ButtonStyle(
                        padding: MaterialStateProperty.all(EdgeInsets.zero)),
                    onPressed: () {
                      state.selectedDateTime = state.dateTimes[index];
                      state.selectedHeader = e;
                      state.notify();
                      // state.getMatchs();
                      state.getMatchsV2();
                    },
                    child: Column(
                      children: [
                        Text(
                          e,
                          style: TextStyle(
                              color: selected
                                  ? theme.isDarkMode
                                      ? Colors.white
                                      : mainColor
                                  : Colors.grey,
                              fontSize: 13.5,
                              fontWeight: selected ? FontWeight.bold : null),
                        ),
                        SizedBox(height: doubleHeight(.5)),
                        Text(
                          state.subDates[index],
                          style: TextStyle(
                              color: selected
                                  ? theme.isDarkMode
                                      ? Colors.white
                                      : mainColor
                                  : Colors.grey,
                              fontSize: 11),
                        ),
                      ],
                    ));
              }).toList(),
              Builder(builder: (context) {
                late Color backColor;
                late Color color = Colors.black;
                  bool selected = state.selectedHeader == 'Date';
                  if (selected) {
                    if (theme.isDarkMode) {
                      backColor = mainGreen;
                    } else {
                      backColor = mainBlue;
                      color = Colors.white;
                    }
                  } else {
                    
                    if (theme.isDarkMode) {
                      color=Colors.white;
                      backColor = Colors.transparent;
                    } else {
                      backColor = Colors.transparent;
                    }
                  }
                return GestureDetector(
                onTap: () async {
                  DateTime? date = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now().add(Duration(days: -365)),
                      lastDate: DateTime.now().add(Duration(days: 365)));
                  if (date != null) {
                    state.selectedHeader = 'Date';
                    state.selectedDateTime = date;
                    state.notify();
                    state.getMatchsV2();
                  }
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: backColor,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  padding: EdgeInsets.all(2),
                  child: Icon(
                    Icons.calendar_month_outlined,
                    color: color,
                    size: 28,
                  ),
                ),
              );
              }),
            ]);
      },
    );
  }
}
