import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:shooting_app/classes/states/match_state.dart';

import '../../../../classes/dataTypes.dart';
import '../../../../classes/functions.dart';
import '../../../../classes/live_match_model.dart';
import '../../../../classes/states/theme_state.dart';

class Country extends StatelessWidget {
  const Country({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
     
    return Consumer2<MatchState, ThemeState>(
      builder: (context, state, theme, child) {
        if (!state.loadCountry)
          return Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: theme.isDarkMode ? Colors.grey : Colors.white),
            child: DropdownButton<DataCountry>(
              items: state.countries
                  .map((e) => DropdownMenuItem<DataCountry>(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('${e.name} ' +
                                '${e.code != null ? '(${e.code})' : ''}'),
                            if (e.flag != null) SizedBox(width: doubleWidth(2)),
                            if (e.flag != null)
                              SizedBox(
                                width: doubleWidth(7),
                                height: doubleWidth(5),
                                child: SvgPicture.network(
                                  e.flag!,
                                  placeholderBuilder: (_) =>
                                      CircularProgressIndicator(),
                                  fit: BoxFit.fill,
                                ),
                              )
                          ],
                        ),
                        value: e,
                      ))
                  .toList(),
              elevation: 3,
              dropdownColor: theme.isDarkMode ? Colors.grey : grayCallLight,
              menuMaxHeight: doubleHeight(70),
              onChanged: (e) {
                if (e != null) {
                  state.country = e;
                  state.cont = e.name;
                  state.notify();
                  // state.getLeagues();
                  state.getMatchsV2();
                }
              },
              value: state.country,
              borderRadius: BorderRadius.circular(10),
              underline: const SizedBox(),
              isExpanded: true,
              icon: Icon(Icons.keyboard_arrow_down_outlined),
              iconSize: 30,
            ),
            padding: EdgeInsets.symmetric(
                horizontal: doubleWidth(4), vertical: doubleHeight(1)),
          );
        else
          return simpleCircle();
      },
    );
  }
}
